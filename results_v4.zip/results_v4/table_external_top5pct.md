| model                      |   recall_top5pct |   precision_top5pct |   lift_top5pct |
|:---------------------------|-----------------:|--------------------:|---------------:|
| Logistic Regression        |         0.349676 |           0.0285518 |        6.99346 |
| MLP                        |         0.368872 |           0.0301191 |        7.37737 |
| Proposed (adaptive fusion) |         0.378988 |           0.0309452 |        7.57971 |
| Alternative-only           |         0.320882 |           0.0262007 |        6.41759 |
| Concatenation              |         0.372698 |           0.0304316 |        7.4539  |
| Financial-only             |         0.259339 |           0.0211755 |        5.18673 |
| Fixed-weight fusion        |         0.376783 |           0.0307652 |        7.53561 |
| Random Forest              |         0.400519 |           0.0327032 |        8.01031 |
| XGBoost                    |         0.358495 |           0.0292719 |        7.16985 |