| comparison                                        | metric   |    mean_diff |     ci95_low |    ci95_high |   bootstrap_p |
|:--------------------------------------------------|:---------|-------------:|-------------:|-------------:|--------------:|
| Proposed (adaptive fusion) vs Logistic Regression | roc_auc  |  0.000447169 | -0.00264107  |  0.0037756   |          0.77 |
| Proposed (adaptive fusion) vs Logistic Regression | pr_auc   |  0.0051881   |  0.00220371  |  0.00872161  |          0    |
| Proposed (adaptive fusion) vs Random Forest       | roc_auc  | -0.0191604   | -0.0248161   | -0.0141666   |          0    |
| Proposed (adaptive fusion) vs Random Forest       | pr_auc   | -0.00225217  | -0.00839304  |  0.00422761  |          0.46 |
| Proposed (adaptive fusion) vs XGBoost             | roc_auc  | -0.00426695  | -0.00948856  |  0.00123143  |          0.11 |
| Proposed (adaptive fusion) vs XGBoost             | pr_auc   |  0.00462749  | -0.00072797  |  0.0101685   |          0.13 |
| Proposed (adaptive fusion) vs MLP                 | roc_auc  | -0.0140445   | -0.0170244   | -0.0109929   |          0    |
| Proposed (adaptive fusion) vs MLP                 | pr_auc   | -0.00110297  | -0.00451381  |  0.00194872  |          0.55 |
| Proposed (adaptive fusion) vs Concatenation       | roc_auc  | -0.000785102 | -0.00211255  |  0.000746612 |          0.31 |
| Proposed (adaptive fusion) vs Concatenation       | pr_auc   |  0.00296243  |  0.000307259 |  0.0056829   |          0.04 |
| Proposed (adaptive fusion) vs Fixed-weight fusion | roc_auc  | -0.00346937  | -0.00487467  | -0.00216813  |          0    |
| Proposed (adaptive fusion) vs Fixed-weight fusion | pr_auc   |  0.000781194 | -0.00333903  |  0.00418354  |          0.6  |