| model                      |   recall_top5pct |   precision_top5pct |   lift_top5pct |
|:---------------------------|-----------------:|--------------------:|---------------:|
| Logistic Regression        |         0.324681 |           0.147487  |        6.4932  |
| MLP                        |         0.341418 |           0.15509   |        6.82793 |
| Proposed (adaptive fusion) |         0.337021 |           0.153093  |        6.73999 |
| Alternative-only           |         0.269362 |           0.122358  |        5.38689 |
| Concatenation              |         0.336312 |           0.152771  |        6.72581 |
| Financial-only             |         0.205674 |           0.0934278 |        4.11321 |
| Fixed-weight fusion        |         0.337305 |           0.153222  |        6.74566 |
| Random Forest              |         0.319291 |           0.145039  |        6.3854  |
| XGBoost                    |         0.333759 |           0.151611  |        6.67475 |