# Reviewer comment -> where the evidence is (files in this folder)

Items marked MANUAL need text written in the manuscript; no script can do that for you.
Every number you quote must be copied from these files, never typed from memory.

## Reviewer R1
 1  Dataset / sample size / setting in abstract ..... manuscript_snippets.md (abstract sentence), dataset_summary.csv
 2  Research gap .................................... MANUAL (introduction); use the limitations list in manuscript_snippets.md
 3  Reformulate contributions ....................... MANUAL (computational novelty = instance-wise fusion with learned scoring net, evaluated by ablation)
 4  Critical comparison with refs [20],[22]-[25] .... MANUAL (related work)
 5  Improve Table 1 (datasets, metrics, limitations)  MANUAL
 6  Exact release, source, period, loans, classes ... dataset_summary.csv, run_config.json (audit), manuscript_snippets.md
 7  Target definition, horizon, window, censoring ... dataset_summary.csv (obs_months_K, horizon_H, dq_threshold, exclusions), header of the script
 8  Financial vs alternative modality ............... feature_list.csv (modality column), manuscript_snippets.md (limitations)
 9  Temporal leakage ................................ dataset_summary.csv (temporal_integrity_check), sanity_checks.json (shuffled-label AUC ~ 0.5)
10  Feature list, missing values, encoding, scaling . feature_list.csv  (all transforms fitted on training data only)
11  Encoder architecture ............................ manuscript_snippets.md (training configuration), run_config.json (best hidden size / dropout)
12  Fusion score computation ........................ manuscript_snippets.md (Eqs. 4-7 with the scoring network)
13  Training configuration .......................... run_config.json, tuning_log.csv, manuscript_snippets.md
14  70/15/15 split .................................. run_config.json (split_info)
15  Split BEFORE preprocessing (Algorithm 1) ........ MANUAL: reorder Algorithm 1; the code does split -> fit on train -> transform
16  Eq. (9) and (10) ................................ manuscript_snippets.md
17  Reference accuracy / DOIs ....................... MANUAL

## Reviewer R2
 1  Explainability claim ............................ shap_global_importance.csv, fig_shap_global.png
 2  Why adaptive fusion over concat / fixed ......... table4_ablation_random_split, table_stat_tests_*
 3  Baseline selection and tuning ................... tuning_log.csv, run_config.json (same budget for every model)
 4  Table 3 vs Figure 2 mismatch .................... table3_main_comparison_random_split + fig2_model_comparison.png (same data)
 5  Figure 3 (modality ROC) ......................... fig3_modality_ablation_roc_pr.png (ablation models only)
 6  Test size, counts, confusion matrix, class-wise . table_confusion_and_classwise_run0
 7  Variability, CI, significance ................... table3 (mean +- SD, 95% CI), table_stat_tests_across_runs, table_stat_tests_bootstrap_run0
 8  Controlled ablation ............................. table4_ablation_random_split
 9  Calibration, PR-AUC, cost-sensitive ............. fig5_calibration.png, table3 (PR-AUC, Brier, ECE), table_cost_sensitive, fig6_cost_sensitive.png
10  SHAP, borrower-level explanations ............... shap_global_importance.csv, shap_borrower_level.csv, fig_shap_borrower_level.png
11  Temporal / external validation .................. table_out_of_time_validation, fig_oot_modality_roc_pr.png, table_external_validation_2018Q1, fig_external_modality_roc_pr.png, table_external_top5pct, table_stat_tests_*_external
12  Class imbalance ................................. table_class_imbalance_study, table_top5pct_highrisk_identification
13  Modality contribution by risk group ............. fusion_weights_by_risk_group.csv, fig_fusion_weights.png, shap_modality_share.csv; CHECK fusion_weights_stability_across_runs.csv first - interpret the weights only if they are stable across runs
14  Limitations, representativeness, bias ........... manuscript_snippets.md (limitations), subgroup_audit.csv
15  Figures generated from verified results ......... all figures are produced from results_all_runs.csv / stored predictions
16  Section 4 numbering (4.1, 4.2 missing) .......... MANUAL
17  Conclusion only on demonstrated findings ........ MANUAL: write it from tables 3, 4, out-of-time; qualify anything not shown
18  Data / code / reproducibility statements ........ manuscript_snippets.md, run_config.json, run_log.txt

## Editorial requirements
Highlight every change in yellow (Word + PDF), cite figures/tables in order, verify references and DOIs: MANUAL.
