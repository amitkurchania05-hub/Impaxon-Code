| comparison                                        | metric   |    mean_diff |   runs |   paired_t_p |   wilcoxon_p |
|:--------------------------------------------------|:---------|-------------:|-------:|-------------:|-------------:|
| Proposed (adaptive fusion) vs Logistic Regression | pr_auc   |  0.00879604  |     10 |  0.00103411  |   0.00195312 |
| Proposed (adaptive fusion) vs Logistic Regression | roc_auc  |  0.00152917  |     10 |  0.0957536   |   0.0839844  |
| Proposed (adaptive fusion) vs Logistic Regression | f1       |  0.00522163  |     10 |  0.0881521   |   0.232422   |
| Proposed (adaptive fusion) vs Random Forest       | pr_auc   |  0.0165627   |     10 |  0.00154944  |   0.00585938 |
| Proposed (adaptive fusion) vs Random Forest       | roc_auc  |  0.00990055  |     10 |  7.72755e-06 |   0.00195312 |
| Proposed (adaptive fusion) vs Random Forest       | f1       |  0.0125102   |     10 |  0.0241117   |   0.0371094  |
| Proposed (adaptive fusion) vs XGBoost             | pr_auc   |  0.00582397  |     10 |  0.110491    |   0.130859   |
| Proposed (adaptive fusion) vs XGBoost             | roc_auc  | -0.00190478  |     10 |  0.0184229   |   0.0195312  |
| Proposed (adaptive fusion) vs XGBoost             | f1       | -0.00164059  |     10 |  0.569493    |   0.556641   |
| Proposed (adaptive fusion) vs MLP                 | pr_auc   | -0.00125253  |     10 |  0.343397    |   0.431641   |
| Proposed (adaptive fusion) vs MLP                 | roc_auc  | -0.00299905  |     10 |  0.000235162 |   0.00390625 |
| Proposed (adaptive fusion) vs MLP                 | f1       | -0.00653563  |     10 |  0.0182087   |   0.0195312  |
| Proposed (adaptive fusion) vs Concatenation       | pr_auc   |  0.000893251 |     10 |  0.118431    |   0.160156   |
| Proposed (adaptive fusion) vs Concatenation       | roc_auc  |  0.000600673 |     10 |  0.07105     |   0.0644531  |
| Proposed (adaptive fusion) vs Concatenation       | f1       | -0.00259661  |     10 |  0.0926815   |   0.105469   |
| Proposed (adaptive fusion) vs Fixed-weight fusion | pr_auc   |  0.000370082 |     10 |  0.520632    |   0.193359   |
| Proposed (adaptive fusion) vs Fixed-weight fusion | roc_auc  |  0.000549188 |     10 |  0.128031    |   0.160156   |
| Proposed (adaptive fusion) vs Fixed-weight fusion | f1       |  0.000556236 |     10 |  0.751106    |   1          |