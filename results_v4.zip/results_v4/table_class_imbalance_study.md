| model                      | weighting                         |   roc_auc |   pr_auc |   recall |   precision |       f1 |   recall_top5pct |    ece_raw |
|:---------------------------|:----------------------------------|----------:|---------:|---------:|------------:|---------:|-----------------:|-----------:|
| Proposed (adaptive fusion) | full inverse-frequency            |  0.840944 | 0.151587 | 0.27234  |    0.192368 | 0.224739 |         0.340898 | 0.280626   |
| Proposed (adaptive fusion) | no weighting                      |  0.839771 | 0.152549 | 0.283215 |    0.178696 | 0.218284 |         0.340898 | 0.00207791 |
| Proposed (adaptive fusion) | sqrt weighting                    |  0.839979 | 0.152966 | 0.300236 |    0.172984 | 0.218882 |         0.338534 | 0.0829197  |
| Proposed (adaptive fusion) | undersampling 1:1 (training only) |  0.83789  | 0.153967 | 0.304492 |    0.168843 | 0.215974 |         0.337116 | 0.300816   |
| XGBoost                    | full inverse-frequency            |  0.842085 | 0.151246 | 0.292671 |    0.173497 | 0.216149 |         0.341844 | 0.290006   |
| XGBoost                    | no weighting                      |  0.84259  | 0.156092 | 0.261939 |    0.200182 | 0.22349  |         0.338534 | 0.00159731 |
| XGBoost                    | sqrt weighting                    |  0.842328 | 0.155508 | 0.266194 |    0.192708 | 0.218346 |         0.343262 | 0.0828849  |
| XGBoost                    | undersampling 1:1 (training only) |  0.83812  | 0.139084 | 0.296927 |    0.165955 | 0.212165 |         0.331442 | 0.312098   |