| comparison                                        | metric   |    mean_diff |    ci95_low |   ci95_high |   bootstrap_p |
|:--------------------------------------------------|:---------|-------------:|------------:|------------:|--------------:|
| Proposed (adaptive fusion) vs Logistic Regression | roc_auc  |  0.00074257  | -0.00236972 | 0.00363638  |         0.612 |
| Proposed (adaptive fusion) vs Logistic Regression | pr_auc   |  0.0133949   |  0.00421273 | 0.0224783   |         0.012 |
| Proposed (adaptive fusion) vs Random Forest       | roc_auc  |  0.0111162   |  0.00378159 | 0.0173862   |         0.004 |
| Proposed (adaptive fusion) vs Random Forest       | pr_auc   |  0.0411552   |  0.0238305  | 0.0590346   |         0     |
| Proposed (adaptive fusion) vs XGBoost             | roc_auc  |  0.00118139  | -0.00423888 | 0.00615671  |         0.648 |
| Proposed (adaptive fusion) vs XGBoost             | pr_auc   |  0.025003    |  0.0107383  | 0.0408234   |         0     |
| Proposed (adaptive fusion) vs MLP                 | roc_auc  | -0.00177637  | -0.00485324 | 0.00119535  |         0.26  |
| Proposed (adaptive fusion) vs MLP                 | pr_auc   |  0.000504284 | -0.00551391 | 0.00624094  |         0.888 |
| Proposed (adaptive fusion) vs Concatenation       | roc_auc  |  0.000222575 | -0.00153038 | 0.00199348  |         0.756 |
| Proposed (adaptive fusion) vs Concatenation       | pr_auc   |  0.000169627 | -0.00449631 | 0.00455947  |         0.904 |
| Proposed (adaptive fusion) vs Fixed-weight fusion | roc_auc  | -0.000135218 | -0.00124809 | 0.000970874 |         0.804 |
| Proposed (adaptive fusion) vs Fixed-weight fusion | pr_auc   | -0.000462544 | -0.00267354 | 0.00165825  |         0.692 |