| comparison                                        | metric   |    mean_diff |   runs |   paired_t_p |   wilcoxon_p |
|:--------------------------------------------------|:---------|-------------:|-------:|-------------:|-------------:|
| Proposed (adaptive fusion) vs Logistic Regression | pr_auc   |  0.00860318  |     10 |  3.85391e-07 |   0.00195312 |
| Proposed (adaptive fusion) vs Logistic Regression | roc_auc  |  0.00869687  |     10 |  0.000234762 |   0.00195312 |
| Proposed (adaptive fusion) vs Logistic Regression | f1       |  0.0333385   |     10 |  0.00266327  |   0.00390625 |
| Proposed (adaptive fusion) vs Random Forest       | pr_auc   | -0.000786899 |     10 |  0.547195    |   0.921875   |
| Proposed (adaptive fusion) vs Random Forest       | roc_auc  | -0.0145027   |     10 |  2.28759e-05 |   0.00195312 |
| Proposed (adaptive fusion) vs Random Forest       | f1       | -0.0134306   |     10 |  0.00980041  |   0.00976562 |
| Proposed (adaptive fusion) vs XGBoost             | pr_auc   |  0.00342705  |     10 |  0.0558525   |   0.0644531  |
| Proposed (adaptive fusion) vs XGBoost             | roc_auc  | -0.00344247  |     10 |  0.109568    |   0.0644531  |
| Proposed (adaptive fusion) vs XGBoost             | f1       | -0.00276216  |     10 |  0.661679    |   0.921875   |
| Proposed (adaptive fusion) vs MLP                 | pr_auc   |  0.00148663  |     10 |  0.19912     |   0.431641   |
| Proposed (adaptive fusion) vs MLP                 | roc_auc  | -0.0076421   |     10 |  0.0012779   |   0.00195312 |
| Proposed (adaptive fusion) vs MLP                 | f1       | -0.00542483  |     10 |  0.208423    |   0.193359   |
| Proposed (adaptive fusion) vs Concatenation       | pr_auc   |  0.00219648  |     10 |  0.0900839   |   0.130859   |
| Proposed (adaptive fusion) vs Concatenation       | roc_auc  |  0.00057222  |     10 |  0.572861    |   0.695312   |
| Proposed (adaptive fusion) vs Concatenation       | f1       |  0.0143017   |     10 |  0.0622607   |   0.0644531  |
| Proposed (adaptive fusion) vs Fixed-weight fusion | pr_auc   |  0.00263698  |     10 |  0.0390338   |   0.0488281  |
| Proposed (adaptive fusion) vs Fixed-weight fusion | roc_auc  | -0.000165976 |     10 |  0.858381    |   0.695312   |
| Proposed (adaptive fusion) vs Fixed-weight fusion | f1       |  0.0258405   |     10 |  0.00172801  |   0.00390625 |