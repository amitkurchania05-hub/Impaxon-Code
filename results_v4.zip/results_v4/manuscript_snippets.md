# Auto-generated manuscript text (values come from this run)

## Abstract sentence (R1-1)

Experiments use the Fannie Mae Single-Family Loan Performance Data (2007Q1.parquet; 206,914 eligible loans, 2.2691% positive). The adverse outcome is a delinquency of at least 3 month(s) within 12 month(s) after the prediction date; performance is reported on a held-out stratified test set of 31,038 loans (705 defaults) as mean � SD over 10 independent runs, plus an out-of-time test within the vintage, plus an external test on a different vintage.

## Dataset and target definition (R1-6, R1-7, R1-9)

{
  "files": [
    "D:\\Amit-USA\\Impaxon\\2007Q1.parquet"
  ],
  "n_rows_raw": 16588215,
  "n_duplicate_loan_months_removed": 0,
  "n_inconsistent_fico_set_missing": 0,
  "n_inconsistent_dti_set_missing": 0,
  "n_inconsistent_ltv_set_missing": 0,
  "n_inconsistent_cltv_set_missing": 0,
  "n_inconsistent_co_fico_set_missing": 0,
  "n_loans_total": 253279,
  "first_reporting_month_range": [
    "2007-01",
    "2007-03"
  ],
  "n_loans_with_record_at_t0": 237222,
  "n_excluded_delinquent_at_t0": 5717,
  "n_excluded_censored_in_window": 24591,
  "temporal_integrity_check": "passed: feature rows t<=t0 < label rows t>t0",
  "obs_months_K": 12,
  "horizon_H": 12,
  "dq_threshold": 3,
  "n_eligible_loans": 206914,
  "n_positive": 4695,
  "n_negative": 202219,
  "prevalence_pct": 2.2691,
  "prediction_month_counts": {
    "2008-01": 62966,
    "2008-02": 71702,
    "2008-03": 72246
  },
  "out_of_time_snapshot": {
    "obs_months_K": 24,
    "n_eligible_loans": 159537,
    "n_positive": 8438,
    "prevalence_pct": 5.2891
  },
  "external_test": {
    "files": [
      "D:\\Amit-USA\\Impaxon\\2018Q1.csv"
    ],
    "n_rows_raw": 23563399,
    "n_loans_total": 458830,
    "first_reporting_month_range": [
      "2018-01",
      "2018-03"
    ],
    "n_excluded_delinquent_at_t0": 4293,
    "n_excluded_censored_in_window": 57932,
    "n_eligible_loans": 377697,
    "n_positive": 1542,
    "prevalence_pct": 0.4083
  }
}

Features use only loan-month records at or before the prediction date t0; the label uses only records after t0. Loans delinquent at t0 and loans with an incomplete window (e.g. prepaid) are excluded (counts above).

## Split (R1-14)

Stratified 70% / 15% / 15% train / validation / test; all imputers, scalers and encoders are fitted on the training part only (Algorithm 1 must split BEFORE preprocessing). {"random": {"n_train": 144839, "n_val": 31037, "n_test": 31038, "pos_train": 3286, "pos_val": 704, "pos_test": 705, "neg_test": 30333}, "oot": {"n_train": 123153, "n_val": 21734, "n_test": 47885, "pos_train": 2785, "pos_val": 491, "pos_test": 2495, "neg_test": 45390}, "external": {"n_train": 175876, "n_val": 31038, "n_test": 377697, "pos_train": 3991, "pos_val": 704, "pos_test": 1542, "neg_test": 376155}}

## Equations (R1-16)

Eq. (9):  P(Y=1 | X) = sigma(z) = 1 / (1 + exp(-z))

Eq. (10): Y_hat = 1 if P(Y=1 | X) >= tau, else 0, with tau chosen on the validation set (max F1, or min expected cost)

Eqs. (4)-(7) with a learnable scoring network (R1-12): H_m = P_m(f_m(X_m)) in R^D (D=32, P_m linear projection);  s_m = v^T tanh(U H_m + c), m in {f, a} (U in R^{16 x 32}, v in R^16, shared by both modalities);  [alpha, beta] = softmax([s_f, s_a]);  H_fusion = alpha H_f + beta H_a;  z = W H_fusion + b. Weights are instance-wise.

## Training configuration (R1-13)

{
  "optimizer": "AdamW",
  "batch_size": 1024,
  "max_epochs": 60,
  "class_imbalance": "training set balanced 1:1 by random undersampling after the split; validation and test keep the natural rate; probabilities recalibrated (Platt) on the natural-rate validation set",
  "early_stopping": "patience 8 on validation PR-AUC",
  "loss": "binary cross-entropy with positive weight 1.00 ((n_neg/n_pos)^0.5)",
  "seeds": [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9
  ],
  "encoder": "Linear(d,h)-ReLU-Dropout-Linear(h,h/2)-ReLU",
  "tuned_hyperparameters_per_model": {
    "logreg": {
      "C": 1.0
    },
    "rf": {
      "max_depth": 10,
      "min_samples_leaf": 20,
      "max_features": "sqrt"
    },
    "xgboost": {
      "n_estimators": 200,
      "max_depth": 4,
      "learning_rate": 0.13940095486175827,
      "subsample": 0.9,
      "colsample_bytree": 0.9,
      "min_child_weight": 5,
      "reg_lambda": 5.0
    },
    "mlp": {
      "lr": 0.0031025946414823856,
      "dropout": 0.4,
      "hidden": 128,
      "wd": 1e-05
    },
    "mmai_fin_only": {
      "lr": 0.002106510832528192,
      "dropout": 0.3,
      "hidden": 32,
      "wd": 0.001
    },
    "mmai_alt_only": {
      "lr": 0.0012381828835575795,
      "dropout": 0.2,
      "hidden": 64,
      "wd": 1e-05
    },
    "mmai_concat": {
      "lr": 0.002106510832528192,
      "dropout": 0.3,
      "hidden": 32,
      "wd": 0.001
    },
    "mmai_fixed": {
      "lr": 0.002106510832528192,
      "dropout": 0.3,
      "hidden": 32,
      "wd": 0.001
    },
    "mmai_adaptive": {
      "lr": 0.002106510832528192,
      "dropout": 0.3,
      "hidden": 32,
      "wd": 0.001
    }
  },
  "software": {
    "python": "3.11.8",
    "platform": "Windows-10-10.0.26300-SP0",
    "numpy": "2.1.3",
    "pandas": "2.2.3",
    "torch": "2.7.0+cu118",
    "device": "cuda",
    "cpu_count": 16,
    "sklearn": "1.6.1",
    "xgboost": "3.0.5"
  }
}

## Reproducibility statements (R2-18)

Data availability: the Fannie Mae Single-Family Loan Performance Data are publicly available after free registration at https://capitalmarkets.fanniemae.com (Data Dynamics). The exact file(s) used: 2007Q1.parquet.

Code availability: the complete pipeline (this script) regenerates all tables and figures; deposit it in a public repository (e.g. GitHub/Zenodo) and cite the DOI here.

## Limitations to state (R2-14, R2-17)

- Fannie Mae data contain no genuine alternative data (rent, utility, transaction); 'alternative' here means non-underwriting behavioural and contextual signals.
- Single acquisition vintage (2007Q1, a financial-crisis-era vintage; results do not describe current lending) / fixed-rate, full-documentation, conventional loans only: limited representativeness.
- Prevalence differs strongly across vintages, so probabilities calibrated on the training vintage are not valid for another vintage without recalibration; external results are therefore reported mainly through ranking metrics (ROC-AUC, PR-AUC, lift).
- Very low default prevalence and short seasoning limit statistical power; confidence intervals are reported.
- Features such as geography, seller/servicer and channel can encode proxy bias; see subgroup_audit.csv.
- Explainability is shown with SHAP on the trained model; it describes model behaviour, not causal effects.
