| comparison                                        | metric   |    mean_diff |    ci95_low |    ci95_high |   bootstrap_p |
|:--------------------------------------------------|:---------|-------------:|------------:|-------------:|--------------:|
| Proposed (adaptive fusion) vs Logistic Regression | roc_auc  | -0.00205206  | -0.00767251 |  0.00367371  |         0.52  |
| Proposed (adaptive fusion) vs Logistic Regression | pr_auc   |  0.00855563  | -0.0038884  |  0.0221832   |         0.212 |
| Proposed (adaptive fusion) vs Random Forest       | roc_auc  |  0.000607953 | -0.00633715 |  0.00698883  |         0.868 |
| Proposed (adaptive fusion) vs Random Forest       | pr_auc   |  0.0116526   | -0.00286165 |  0.0264499   |         0.112 |
| Proposed (adaptive fusion) vs XGBoost             | roc_auc  | -0.0046129   | -0.010834   |  0.0018726   |         0.144 |
| Proposed (adaptive fusion) vs XGBoost             | pr_auc   |  0.00331169  | -0.0103941  |  0.016339    |         0.62  |
| Proposed (adaptive fusion) vs MLP                 | roc_auc  | -0.00485106  | -0.00980912 |  0.000390778 |         0.08  |
| Proposed (adaptive fusion) vs MLP                 | pr_auc   |  0.00797513  | -0.00349267 |  0.019261    |         0.184 |
| Proposed (adaptive fusion) vs Concatenation       | roc_auc  | -0.00507089  | -0.0098137  | -0.000265861 |         0.028 |
| Proposed (adaptive fusion) vs Concatenation       | pr_auc   |  0.00727809  | -0.00167008 |  0.01712     |         0.116 |
| Proposed (adaptive fusion) vs Fixed-weight fusion | roc_auc  | -0.00490905  | -0.0092087  | -0.000119801 |         0.048 |
| Proposed (adaptive fusion) vs Fixed-weight fusion | pr_auc   |  0.00276286  | -0.00736575 |  0.0122878   |         0.556 |