| comparison                                        | metric   |    mean_diff |   runs |   paired_t_p |   wilcoxon_p |
|:--------------------------------------------------|:---------|-------------:|-------:|-------------:|-------------:|
| Proposed (adaptive fusion) vs Logistic Regression | pr_auc   |  0.00714304  |      5 |   0.00703265 |       0.0625 |
| Proposed (adaptive fusion) vs Logistic Regression | roc_auc  |  0.000373275 |      5 |   0.864612   |       0.8125 |
| Proposed (adaptive fusion) vs Logistic Regression | f1       |  0.00559686  |      5 |   0.322432   |       0.4375 |
| Proposed (adaptive fusion) vs Random Forest       | pr_auc   |  0.00213627  |      5 |   0.54241    |       0.8125 |
| Proposed (adaptive fusion) vs Random Forest       | roc_auc  |  0.0033417   |      5 |   0.0822433  |       0.125  |
| Proposed (adaptive fusion) vs Random Forest       | f1       | -0.00135683  |      5 |   0.707224   |       1      |
| Proposed (adaptive fusion) vs XGBoost             | pr_auc   | -0.00548791  |      5 |   0.252576   |       0.3125 |
| Proposed (adaptive fusion) vs XGBoost             | roc_auc  | -0.00349115  |      5 |   0.0048611  |       0.0625 |
| Proposed (adaptive fusion) vs XGBoost             | f1       | -0.00482447  |      5 |   0.236067   |       0.3125 |
| Proposed (adaptive fusion) vs MLP                 | pr_auc   | -8.49542e-05 |      5 |   0.980455   |       1      |
| Proposed (adaptive fusion) vs MLP                 | roc_auc  | -0.00177124  |      5 |   0.325331   |       0.625  |
| Proposed (adaptive fusion) vs MLP                 | f1       | -0.00547259  |      5 |   0.0322167  |       0.125  |
| Proposed (adaptive fusion) vs Concatenation       | pr_auc   | -0.000431549 |      5 |   0.849143   |       0.625  |
| Proposed (adaptive fusion) vs Concatenation       | roc_auc  | -0.00141507  |      5 |   0.387124   |       0.4375 |
| Proposed (adaptive fusion) vs Concatenation       | f1       | -0.00443115  |      5 |   0.360909   |       0.4375 |
| Proposed (adaptive fusion) vs Fixed-weight fusion | pr_auc   | -0.000426334 |      5 |   0.813575   |       1      |
| Proposed (adaptive fusion) vs Fixed-weight fusion | roc_auc  | -0.000390063 |      5 |   0.869384   |       0.8125 |
| Proposed (adaptive fusion) vs Fixed-weight fusion | f1       | -0.00574336  |      5 |   0.197171   |       0.3125 |