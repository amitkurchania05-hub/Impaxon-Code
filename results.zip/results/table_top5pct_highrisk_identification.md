| model                         |   recall_top5pct |   precision_top5pct |   lift_top5pct |
|:------------------------------|-----------------:|--------------------:|---------------:|
| Majority-class (all low-risk) |       nan        |         nan         |      nan       |
| Logistic Regression           |         0.333333 |           0.151418  |        6.66624 |
| MLP                           |         0.337589 |           0.153351  |        6.75134 |
| Proposed (adaptive fusion)    |         0.336454 |           0.152835  |        6.72864 |
| Alternative-only              |         0.279716 |           0.127062  |        5.59397 |
| Concatenation                 |         0.339291 |           0.154124  |        6.78538 |
| Financial-only                |         0.215603 |           0.0979381 |        4.31178 |
| Fixed-weight fusion           |         0.336738 |           0.152964  |        6.73432 |
| Random Forest                 |         0.333617 |           0.151546  |        6.67191 |
| XGBoost                       |         0.341844 |           0.155284  |        6.83644 |