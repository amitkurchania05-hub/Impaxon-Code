| model                      | weighting                |   roc_auc |   pr_auc |   recall |   precision |       f1 |   recall_top5pct |    ece_raw |
|:---------------------------|:-------------------------|----------:|---------:|---------:|------------:|---------:|-----------------:|-----------:|
| Proposed (adaptive fusion) | full inverse-frequency   |  0.840248 | 0.157777 | 0.262411 |    0.199783 | 0.22352  |         0.343262 | 0.295286   |
| Proposed (adaptive fusion) | no weighting             |  0.840281 | 0.152486 | 0.290307 |    0.173923 | 0.217128 |         0.337116 | 0.00295788 |
| Proposed (adaptive fusion) | sqrt weighting (default) |  0.838592 | 0.153706 | 0.321513 |    0.157416 | 0.211144 |         0.334752 | 0.0713396  |
| XGBoost                    | full inverse-frequency   |  0.842085 | 0.151246 | 0.292671 |    0.173497 | 0.216149 |         0.341844 | 0.290006   |
| XGBoost                    | no weighting             |  0.84259  | 0.156092 | 0.261939 |    0.200182 | 0.22349  |         0.338534 | 0.00159731 |
| XGBoost                    | sqrt weighting (default) |  0.842328 | 0.155508 | 0.266194 |    0.192708 | 0.218346 |         0.343262 | 0.0828849  |